# 공유 MCP 서버

OpenCode(OC2)와 이후 OpenClaw가 함께 쓰는 HTTP MCP 서버입니다. 2026-11-21에 폴더마다 MCP를 띄우던 구조를 대체하려고 만들었습니다.

| 서버 | launchd 라벨 | 주소 | 실행 |
| --- | --- | --- | --- |
| Context7 | `io.wineoflove.mcp.context7` | `http://127.0.0.1:5121/mcp` | `bin/loopback-guard.mjs`로 loopback 바인딩·Host 검사, `MCP_AUTH_ENFORCEMENT=observe` |
| Firecrawl | `io.wineoflove.mcp.firecrawl` | `http://127.0.0.1:5122/mcp` | `bin/firecrawl.sh`가 실행 시 키 파일에서 키를 읽음 |
| MarkItDown | `io.wineoflove.mcp.markitdown` | `http://127.0.0.1:5123/mcp` | 내장 DNS rebinding 보호(127.0.0.1) |
| Exa | `io.wineoflove.mcp.exa` | `http://127.0.0.1:5124/mcp` | `bin/exa-proxy.mjs`가 `mcp.exa.ai`로 중계하며 요청마다 키 파일을 읽음 |

- 패키지 원본은 `~/apps/ocm-v2-staging/data/workspace/.opencode/tooling/npm-mcp`와 `.../tooling/markitdown`에 있습니다.
- plist는 `bin/write-plists.py`로 생성합니다. 키는 plist나 이 디렉터리에 저장하지 않습니다.
- 로그: `logs/<이름>.log`
- 확인: `node bin/smoke.mjs`(도구 목록·동시 접속·Host 거부), `node bin/call-smoke.mjs`(실제 도구 호출)
- 재시작: `launchctl kickstart -k gui/$(id -u)/io.wineoflove.mcp.<이름>`
- OpenCode 전역 설정(`.config/opencode/opencode.jsonc`)의 `context7`, `firecrawl`, `markitdown`, `websearch` 항목이 이 주소를 씁니다. 되돌릴 원본: `~/apps/ocm-v2-staging/run/stability-20261121/opencode.jsonc.before-shared-mcp`
