import { spawn } from 'node:child_process'

const KILL_GRACE_MS = 3000

export function terminate(child) {
  if (child.exitCode !== null || child.signalCode !== null) return
  child.kill('SIGTERM')
  const timer = setTimeout(() => {
    if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL')
  }, KILL_GRACE_MS)
  timer.unref()
}

export function runCommand(
  command,
  args,
  { env, cwd, signal, timeoutMs = 30_000, maxOutputBytes = 8 * 1024 * 1024 } = {},
) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { env, cwd, stdio: ['ignore', 'pipe', 'pipe'] })
    const stdout = []
    const stderr = []
    let outputBytes = 0
    let timedOut = false
    let overflow = false

    const collect = (target) => (chunk) => {
      outputBytes += chunk.length
      if (outputBytes > maxOutputBytes) {
        overflow = true
        terminate(child)
        return
      }
      target.push(chunk)
    }

    const timer = setTimeout(() => {
      timedOut = true
      terminate(child)
    }, timeoutMs)
    const onAbort = () => terminate(child)
    signal?.addEventListener('abort', onAbort, { once: true })

    child.stdout.on('data', collect(stdout))
    child.stderr.on('data', collect(stderr))
    child.on('error', (error) => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
      reject(error)
    })
    child.on('close', (code, closeSignal) => {
      clearTimeout(timer)
      signal?.removeEventListener('abort', onAbort)
      resolve({
        code,
        signal: closeSignal,
        timedOut,
        overflow,
        aborted: signal?.aborted === true,
        stdout: Buffer.concat(stdout).toString('utf8'),
        stderr: Buffer.concat(stderr).toString('utf8'),
      })
    })
  })
}
