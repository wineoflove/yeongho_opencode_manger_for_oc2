import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { walkFiles } from './archive.mjs'

const MAX_SCANNED_BYTES = 4 * 1024 * 1024
const MAX_TOKENS = 600
const COLOR_VALUE =
  /^(#[0-9a-f]{3,8}|(rgba?|hsla?|hwb|lab|lch|oklab|oklch|color|color-mix)\(.*\)|transparent|currentcolor)$/i
const DIMENSION_VALUE = /^-?\d*\.?\d+(px|rem|em|%|vh|vw|vmin|vmax|ch|pt)$/i
const CATEGORY_RULES = [
  ['shadow', (name) => /shadow|elevation/.test(name)],
  ['motion', (name, value) => /duration|easing|ease|transition|motion|delay/.test(name) || /^\d+m?s$/.test(value)],
  ['typography', (name) => /font|family|typeface|leading|line-height|tracking|letter|weight|text-size/.test(name)],
  ['color', (name, value) => COLOR_VALUE.test(value)],
  ['radius', (name) => /radius|rounded|corner/.test(name)],
  [
    'dimension',
    (name, value) => /space|spacing|gap|pad|margin|inset|size|width|height/.test(name) || DIMENSION_VALUE.test(value),
  ],
]

export function categorize(name, value) {
  const lowered = name.toLowerCase()
  return CATEGORY_RULES.find(([, matches]) => matches(lowered, value))?.[0] ?? 'other'
}

function stripComments(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, '')
}

export function extractCustomProperties(css) {
  const properties = []
  const blocks = /([^{}]*)\{([^{}]*)\}/g
  for (const [, prelude, body] of stripComments(css).matchAll(blocks)) {
    const selector = prelude.trim().replace(/\s+/g, ' ')
    for (const [, name, rawValue] of body.matchAll(/(--[A-Za-z0-9_-]+)\s*:\s*([^;]+)/g)) {
      const value = rawValue.trim().replace(/\s+/g, ' ')
      if (value.length > 0) properties.push({ name, value, selector })
    }
  }
  return properties
}

export function extractStyleBlocks(html) {
  return [...html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)].map(([, css]) => css).join('\n')
}

export async function collectTokens(contentDir) {
  const files = (await walkFiles(contentDir)).filter((file) => /\.(css|html?)$/i.test(file.path))
  const tokens = []
  let scannedBytes = 0
  const skipped = []
  for (const file of files) {
    if (scannedBytes + file.size > MAX_SCANNED_BYTES) {
      skipped.push(file.path)
      continue
    }
    scannedBytes += file.size
    const text = await readFile(join(contentDir, file.path), 'utf8')
    const css = /\.css$/i.test(file.path) ? text : extractStyleBlocks(text)
    for (const property of extractCustomProperties(css)) {
      tokens.push({ ...property, file: file.path, category: categorize(property.name, property.value) })
    }
  }

  const seen = new Set()
  const unique = tokens.filter((token) => {
    const key = `${token.name}\u0000${token.value}\u0000${token.selector}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })

  const valuesByName = new Map()
  for (const token of unique) {
    valuesByName.set(token.name, new Set([...(valuesByName.get(token.name) ?? []), token.value]))
  }
  const variants = [...valuesByName.entries()]
    .filter(([, values]) => values.size > 1)
    .map(([name]) => ({
      name,
      values: unique.filter((token) => token.name === name).map(({ value, selector }) => ({ value, selector })),
    }))

  const byCategory = {}
  for (const token of unique.slice(0, MAX_TOKENS)) {
    const { category, ...rest } = token
    byCategory[category] = [...(byCategory[category] ?? []), rest]
  }

  return {
    scannedFiles: files.length - skipped.length,
    skippedFiles: skipped,
    tokenCount: unique.length,
    truncated: unique.length > MAX_TOKENS,
    byCategory,
    variants: variants.slice(0, 100),
  }
}
