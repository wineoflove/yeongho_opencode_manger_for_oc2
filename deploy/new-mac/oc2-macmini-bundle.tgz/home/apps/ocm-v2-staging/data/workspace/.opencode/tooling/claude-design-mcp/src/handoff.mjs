import { createHash, randomBytes } from 'node:crypto'
import { isIP } from 'node:net'
import { homedir } from 'node:os'
import { access, mkdir, readdir, readFile, realpath, rename, rm, stat, writeFile } from 'node:fs/promises'
import { basename, extname, join, sep } from 'node:path'
import { extractArchive, listArchive, walkFiles } from './archive.mjs'
import { ToolError } from './tool-error.mjs'

export const DOWNLOAD_LIMIT_BYTES = 150 * 1024 * 1024
const MAX_REDIRECTS = 5
const README_LIMIT = 12_000
const FILE_LIST_LIMIT = 200
const HANDOFF_HOST = 'api.anthropic.com'
const HANDOFF_PATH = /^\/v1\/design\/h\/([A-Za-z0-9_-]{6,128})\/?$/
const HANDOFF_IN_TEXT = /https:\/\/api\.anthropic\.com\/v1\/design\/h\/[A-Za-z0-9_-]+(?:\?[^\s"'<>)\]]*)?/
const LOCAL_EXTENSIONS = new Map([
  ['.zip', 'archive'],
  ['.tgz', 'archive'],
  ['.gz', 'archive'],
  ['.html', 'html'],
  ['.htm', 'html'],
  ['.pdf', 'pdf'],
  ['.pptx', 'pptx'],
])
const SENSITIVE_SEGMENTS = [
  /^\.ssh$/,
  /^\.gnupg$/,
  /^secrets$/i,
  /^credentials/i,
  /^gh$/,
  /^Keychains$/,
  /^opencode-multi-auth$/,
]
const REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308])
const SINGLE_FILE_NAMES = { html: 'index.html', pdf: 'design.pdf', pptx: 'design.pptx' }

export function findHandoffUrl(text) {
  const match = HANDOFF_IN_TEXT.exec(String(text ?? ''))
  if (!match) return null
  const url = new URL(match[0])
  const id = HANDOFF_PATH.exec(url.pathname)?.[1]
  if (url.hostname !== HANDOFF_HOST || !id) return null
  return { url: url.href, id }
}

function assertSafeRedirect(url) {
  if (url.protocol !== 'https:')
    throw new ToolError(`Refusing a non-HTTPS redirect to ${url.protocol}//${url.hostname}`)
  const hostname = url.hostname.replace(/^\[|\]$/g, '')
  if (isIP(hostname) || hostname === 'localhost' || hostname.endsWith('.local') || hostname.endsWith('.internal')) {
    throw new ToolError(`Refusing a redirect to a local or literal-IP host (${hostname}).`)
  }
}

function describeHttpFailure(status) {
  if (status === 404 || status === 410) {
    return `The handoff link returned HTTP ${status}. Handoff links can expire or be single-use; export a fresh one from Claude Design (Export → Handoff to Claude Code / Send to local coding agent).`
  }
  if (status === 401 || status === 403) return `The handoff link returned HTTP ${status}; it is not publicly fetchable.`
  return `The handoff link returned HTTP ${status}.`
}

async function readCapped(response, limit) {
  const declared = Number(response.headers.get('content-length'))
  if (Number.isFinite(declared) && declared > limit)
    throw new ToolError(`The download is ${declared} bytes; the limit is ${limit}.`)
  const chunks = []
  let received = 0
  for await (const chunk of response.body) {
    received += chunk.length
    if (received > limit) throw new ToolError(`The download exceeded the ${limit}-byte limit.`)
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

export async function downloadHandoff(url, { signal, fetchImpl = fetch, limit = DOWNLOAD_LIMIT_BYTES } = {}) {
  let current = new URL(url)
  for (let hop = 0; hop <= MAX_REDIRECTS; hop += 1) {
    const response = await fetchImpl(current.href, {
      redirect: 'manual',
      signal,
      headers: { 'user-agent': 'claude-design-mcp/0.1 (+local OpenCode bridge)' },
    })
    if (REDIRECT_STATUSES.has(response.status)) {
      const location = response.headers.get('location')
      if (!location) throw new ToolError('The handoff link redirected without a location.')
      current = new URL(location, current)
      assertSafeRedirect(current)
      continue
    }
    if (!response.ok) throw new ToolError(describeHttpFailure(response.status))
    const bytes = await readCapped(response, limit)
    return { bytes, contentType: response.headers.get('content-type') ?? '' }
  }
  throw new ToolError(`The handoff link redirected more than ${MAX_REDIRECTS} times.`)
}

export function detectFormat(bytes, hint = '') {
  if (bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b) return 'archive'
  if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && (bytes[2] === 0x03 || bytes[2] === 0x05)) {
    return 'archive'
  }
  if (bytes.subarray(0, 5).toString('latin1') === '%PDF-') return 'pdf'
  const head = bytes
    .subarray(0, 1024)
    .toString('utf8')
    .replace(/^\uFEFF/, '')
    .trimStart()
    .toLowerCase()
  if (head.startsWith('<') && (head.includes('<html') || head.includes('<!doctype html') || hint === 'html'))
    return 'html'
  if (hint === 'html' && head.length > 0 && !head.includes('\u0000')) return 'html'
  return 'unknown'
}

function isPresentation(entries) {
  const names = new Set(entries.map((entry) => entry.name))
  return names.has('[Content_Types].xml') && entries.some((entry) => entry.name.startsWith('ppt/'))
}

export function defaultImportRoots(env = process.env) {
  const configured = env.CLAUDE_DESIGN_IMPORT_ROOTS?.split(':').filter(Boolean)
  return configured?.length ? configured : [homedir()]
}

export async function resolveLocalSource(path, roots) {
  let resolved
  try {
    resolved = await realpath(path)
  } catch {
    throw new ToolError(`The file does not exist: ${path}`)
  }
  const realRoots = await Promise.all(roots.map((root) => realpath(root).catch(() => null)))
  const inside = realRoots.some((root) => root && (resolved === root || resolved.startsWith(`${root}${sep}`)))
  if (!inside) throw new ToolError(`The file is outside the allowed import roots (${roots.join(', ')}).`)
  if (resolved.split(sep).some((segment) => SENSITIVE_SEGMENTS.some((pattern) => pattern.test(segment)))) {
    throw new ToolError('The file is inside a credential or secret directory; refusing to import it.')
  }
  const kind = LOCAL_EXTENSIONS.get(extname(resolved).toLowerCase())
  if (!kind) throw new ToolError(`Unsupported file type. Use one of: ${[...LOCAL_EXTENSIONS.keys()].join(', ')}`)
  const info = await stat(resolved)
  if (!info.isFile()) throw new ToolError('The path is not a regular file.')
  if (info.size > DOWNLOAD_LIMIT_BYTES)
    throw new ToolError(`The file is ${info.size} bytes; the limit is ${DOWNLOAD_LIMIT_BYTES}.`)
  return { path: resolved, hint: kind }
}

async function exists(path) {
  try {
    await access(path)
    return true
  } catch {
    return false
  }
}

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex')
}

async function materialize(bytes, format, staging, signal) {
  const content = join(staging, 'content')
  await mkdir(content, { recursive: true })
  if (format !== 'archive') {
    await writeFile(join(content, SINGLE_FILE_NAMES[format]), bytes)
    return format
  }
  const archivePath = join(staging, 'source.archive')
  await writeFile(archivePath, bytes)
  try {
    if (isPresentation(await listArchive(archivePath, { signal }))) {
      await writeFile(join(content, SINGLE_FILE_NAMES.pptx), bytes)
      return 'pptx'
    }
    await extractArchive(archivePath, content, { signal })
    return 'bundle'
  } finally {
    await rm(archivePath, { force: true })
  }
}

export async function summarizeBundle(contentDir) {
  const files = await walkFiles(contentDir)
  const byExtension = {}
  for (const file of files) {
    const extension = extname(file.path).toLowerCase() || '(none)'
    byExtension[extension] = (byExtension[extension] ?? 0) + 1
  }
  const depth = (path) => path.split('/').length
  const readmeFile = files
    .filter((file) => /^readme(\.md|\.txt)?$/i.test(basename(file.path)))
    .sort((left, right) => depth(left.path) - depth(right.path))[0]
  const readmeText = readmeFile ? await readFile(join(contentDir, readmeFile.path), 'utf8') : null
  const entryHtml = files
    .filter((file) => /\.html?$/i.test(file.path))
    .map((file) => file.path)
    .sort((left, right) => depth(left) - depth(right) || left.localeCompare(right))
  return {
    fileCount: files.length,
    totalBytes: files.reduce((sum, file) => sum + file.size, 0),
    byExtension,
    entryHtml: entryHtml.slice(0, 20),
    readme: readmeFile
      ? {
          path: readmeFile.path,
          text: readmeText.slice(0, README_LIMIT),
          truncated: readmeText.length > README_LIMIT,
        }
      : null,
    files: files.slice(0, FILE_LIST_LIMIT),
    filesTruncated: files.length > FILE_LIST_LIMIT,
  }
}

async function loadSource(source, { signal, fetchImpl, importRoots }) {
  const handoff = findHandoffUrl(source)
  if (handoff) {
    return {
      bundleId: `h-${handoff.id}`,
      origin: { kind: 'handoff-url', url: handoff.url },
      read: async () => {
        const { bytes, contentType } = await downloadHandoff(handoff.url, { signal, fetchImpl })
        return { bytes, hint: contentType.includes('text/html') ? 'html' : '' }
      },
    }
  }
  if (/^https?:\/\//i.test(String(source).trim())) {
    throw new ToolError('Only Claude Design handoff links (https://api.anthropic.com/v1/design/h/…) can be fetched.')
  }
  const local = await resolveLocalSource(String(source).trim(), importRoots)
  const bytes = await readFile(local.path)
  return {
    bundleId: `f-${sha256(bytes).slice(0, 16)}`,
    origin: { kind: 'local-file', path: local.path },
    read: async () => ({ bytes, hint: local.hint }),
  }
}

export async function importHandoff(source, { bundlesRoot, refresh = false, signal, fetchImpl = fetch, importRoots }) {
  if (typeof source !== 'string' || source.trim().length === 0) throw new ToolError('source is required.')
  const loaded = await loadSource(source, { signal, fetchImpl, importRoots: importRoots ?? defaultImportRoots() })
  const bundleDir = join(bundlesRoot, loaded.bundleId)
  const contentDir = join(bundleDir, 'content')
  const manifestPath = join(bundleDir, 'manifest.json')

  if (!refresh && (await exists(manifestPath))) {
    const manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
    return { ...manifest, directory: contentDir, reused: true, ...(await summarizeBundle(contentDir)) }
  }

  const { bytes, hint } = await loaded.read()
  const detected = detectFormat(bytes, hint)
  if (detected === 'unknown')
    throw new ToolError('The content is not a recognised Claude Design export (archive, HTML, PDF or PPTX).')

  await mkdir(bundlesRoot, { recursive: true })
  const staging = join(bundlesRoot, `.staging-${randomBytes(6).toString('hex')}`)
  try {
    const format = await materialize(bytes, detected, staging, signal)
    const manifest = {
      bundleId: loaded.bundleId,
      format,
      origin: loaded.origin,
      sha256: sha256(bytes),
      bytes: bytes.length,
      importedAt: new Date().toISOString(),
    }
    await writeFile(join(staging, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)
    await rm(bundleDir, { recursive: true, force: true })
    await rename(staging, bundleDir)
    return { ...manifest, directory: contentDir, reused: false, ...(await summarizeBundle(contentDir)) }
  } finally {
    await rm(staging, { recursive: true, force: true })
  }
}

export async function listBundles(bundlesRoot, limit = 10) {
  let names
  try {
    names = await readdir(bundlesRoot)
  } catch {
    return []
  }
  const manifests = await Promise.all(
    names
      .filter((name) => !name.startsWith('.'))
      .map(async (name) => {
        try {
          const manifest = JSON.parse(await readFile(join(bundlesRoot, name, 'manifest.json'), 'utf8'))
          return { ...manifest, directory: join(bundlesRoot, name, 'content') }
        } catch {
          return null
        }
      }),
  )
  return manifests
    .filter(Boolean)
    .sort((left, right) => right.importedAt.localeCompare(left.importedAt))
    .slice(0, limit)
}

export async function resolveBundleDir(bundlesRoot, bundleId) {
  if (typeof bundleId !== 'string' || !/^[hf]-[A-Za-z0-9_-]{6,128}$/.test(bundleId)) {
    throw new ToolError('bundleId must be an ID returned by handoff_import (for example h-abc123 or f-0123abcd…).')
  }
  const contentDir = join(bundlesRoot, bundleId, 'content')
  if (!(await exists(contentDir)))
    throw new ToolError(`No imported bundle named ${bundleId}. Run handoff_import first.`)
  return contentDir
}
