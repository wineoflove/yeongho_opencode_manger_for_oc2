import { spawn } from 'node:child_process'
import { constants } from 'node:fs'
import { access, mkdir, readdir } from 'node:fs/promises'
import { homedir } from 'node:os'
import { delimiter, join } from 'node:path'
import { createInterface } from 'node:readline'
import { runCommand, terminate } from './process.mjs'
import { ToolError, redact } from './tool-error.mjs'

export const DESIGN_SERVER = 'claude-design'
export const DESIGN_MCP_URL = 'https://api.anthropic.com/v1/design/mcp'
const TOOL_PREFIX = `mcp__${DESIGN_SERVER}__`
const MCP_CONFIG = JSON.stringify({ mcpServers: { [DESIGN_SERVER]: { type: 'http', url: DESIGN_MCP_URL } } })
const DESKTOP_BINARY_SUFFIX = ['claude.app', 'Contents', 'MacOS', 'claude']
const PASSTHROUGH_ENV = ['HOME', 'USER', 'LOGNAME', 'PATH', 'SHELL', 'LANG', 'LC_ALL', 'LC_CTYPE', 'TERM']

export const toolName = (operation) => `${TOOL_PREFIX}${operation}`
export const operationOf = (name) =>
  typeof name === 'string' && name.startsWith(TOOL_PREFIX) ? name.slice(TOOL_PREFIX.length) : null

async function isExecutable(path) {
  try {
    await access(path, constants.X_OK)
    return true
  } catch {
    return false
  }
}

function compareVersions(left, right) {
  const parse = (value) => value.split('.').map((part) => Number.parseInt(part, 10) || 0)
  const [a, b] = [parse(left), parse(right)]
  for (let index = 0; index < Math.max(a.length, b.length); index += 1) {
    const difference = (a[index] ?? 0) - (b[index] ?? 0)
    if (difference !== 0) return difference
  }
  return 0
}

export async function findDesktopBinary(
  root = join(homedir(), 'Library', 'Application Support', 'Claude', 'claude-code'),
) {
  let versions
  try {
    versions = (await readdir(root)).filter((name) => /^\d+(\.\d+)+$/.test(name))
  } catch {
    return null
  }
  for (const version of versions.sort(compareVersions).reverse()) {
    const builds = await readdir(join(root, version)).catch(() => [])
    for (const build of builds) {
      const candidate = join(root, version, build, ...DESKTOP_BINARY_SUFFIX)
      if (await isExecutable(candidate)) return candidate
    }
  }
  return null
}

export async function resolveClaudeBinary(env = process.env, desktopRoot) {
  if (env.CLAUDE_DESIGN_CLAUDE_BIN) {
    if (!(await isExecutable(env.CLAUDE_DESIGN_CLAUDE_BIN))) {
      throw new ToolError(`CLAUDE_DESIGN_CLAUDE_BIN is not executable: ${env.CLAUDE_DESIGN_CLAUDE_BIN}`)
    }
    return { path: env.CLAUDE_DESIGN_CLAUDE_BIN, source: 'env' }
  }
  for (const directory of (env.PATH ?? '').split(delimiter).filter(Boolean)) {
    const candidate = join(directory, 'claude')
    if (await isExecutable(candidate)) return { path: candidate, source: 'path' }
  }
  const desktop = await findDesktopBinary(desktopRoot)
  return desktop ? { path: desktop, source: 'claude-desktop' } : null
}

export function childEnvironment(env = process.env) {
  const child = Object.fromEntries(
    PASSTHROUGH_ENV.filter((key) => env[key] !== undefined).map((key) => [key, env[key]]),
  )
  if (env.CLAUDE_DESIGN_CLAUDE_CONFIG_DIR) child.CLAUDE_CONFIG_DIR = env.CLAUDE_DESIGN_CLAUDE_CONFIG_DIR
  child.CLAUDE_CODE_ARTIFACT_AUTO_OPEN = '0'
  child.DISABLE_AUTOUPDATER = '1'
  child.MAX_MCP_OUTPUT_TOKENS = env.CLAUDE_DESIGN_MAX_OUTPUT_TOKENS ?? '50000'
  child.MCP_TOOL_TIMEOUT = env.CLAUDE_DESIGN_MCP_TOOL_TIMEOUT_MS ?? '300000'
  return child
}

export async function readVersion(binary, env) {
  const result = await runCommand(binary, ['--version'], { env: childEnvironment(env), timeoutMs: 20_000 })
  return result.code === 0 ? result.stdout.trim().split(/\s+/)[0] : null
}

export async function readAuthStatus(binary, env) {
  const result = await runCommand(binary, ['auth', 'status'], { env: childEnvironment(env), timeoutMs: 30_000 })
  try {
    const parsed = JSON.parse(result.stdout)
    return {
      loggedIn: parsed.loggedIn === true,
      authMethod: typeof parsed.authMethod === 'string' ? parsed.authMethod : 'unknown',
      apiProvider: typeof parsed.apiProvider === 'string' ? parsed.apiProvider : 'unknown',
    }
  } catch {
    return { loggedIn: false, error: redact(result.stderr || result.stdout || `exit ${result.code}`, 400) }
  }
}

export function workDirectory(env = process.env) {
  return env.CLAUDE_DESIGN_WORK_DIR ?? join(homedir(), '.cache', 'claude-design-mcp', 'work')
}

export function buildArgs({ maxTurns, model, allowedOperations, deniedOperations = [] }) {
  const allowed = allowedOperations ? allowedOperations.map(toolName).join(',') : `mcp__${DESIGN_SERVER}`
  const args = [
    '-p',
    '--output-format',
    'stream-json',
    '--verbose',
    '--tools',
    '',
    '--mcp-config',
    MCP_CONFIG,
    '--strict-mcp-config',
    '--allowedTools',
    allowed,
    '--permission-mode',
    'dontAsk',
    '--no-session-persistence',
    '--disable-slash-commands',
    '--max-turns',
    String(maxTurns),
  ]
  if (deniedOperations.length > 0) args.push('--disallowedTools', deniedOperations.map(toolName).join(','))
  if (model) args.push('--model', model)
  return args
}

function toolResultContent(content) {
  if (typeof content === 'string') return [{ type: 'text', text: content }]
  if (!Array.isArray(content)) return []
  return content.flatMap((block) => {
    if (block?.type === 'text' && typeof block.text === 'string') return [{ type: 'text', text: block.text }]
    if (block?.type === 'image' && block.source?.type === 'base64') {
      return [{ type: 'image', data: block.source.data, mimeType: block.source.media_type }]
    }
    return []
  })
}

export class StreamCollector {
  constructor() {
    this.init = null
    this.calls = []
    this.texts = []
    this.apiError = null
    this.result = null
  }

  accept(event) {
    if (event.type === 'system' && event.subtype === 'init') {
      const servers = Array.isArray(event.mcp_servers) ? event.mcp_servers : []
      this.init = {
        tools: Array.isArray(event.tools) ? event.tools : [],
        serverStatus: servers.find((server) => server?.name === DESIGN_SERVER)?.status ?? 'missing',
        model: event.model,
        version: event.claude_code_version,
      }
      return
    }
    if (event.type === 'assistant') {
      if (typeof event.error === 'string') this.apiError = event.error
      for (const block of event.message?.content ?? []) {
        if (block.type === 'tool_use') {
          this.calls.push({
            id: block.id,
            name: block.name,
            operation: operationOf(block.name),
            input: block.input,
            result: null,
          })
        }
        if (block.type === 'text' && typeof block.text === 'string') this.texts.push(block.text)
      }
      return
    }
    if (event.type === 'user') {
      for (const block of event.message?.content ?? []) {
        if (block.type !== 'tool_result') continue
        const call = this.calls.find((candidate) => candidate.id === block.tool_use_id)
        if (call) call.result = { isError: block.is_error === true, content: toolResultContent(block.content) }
      }
      return
    }
    if (event.type === 'result') {
      this.result = {
        subtype: event.subtype,
        isError: event.is_error === true,
        text: typeof event.result === 'string' ? event.result : '',
        turns: event.num_turns,
        durationMs: event.duration_ms,
        costUsd: typeof event.total_cost_usd === 'number' ? event.total_cost_usd : null,
      }
    }
  }

  get operations() {
    return this.init ? this.init.tools.map(operationOf).filter(Boolean).sort() : []
  }

  get designAvailable() {
    return this.init ? this.operations.length > 0 : null
  }

  designCalls() {
    return this.calls.filter((call) => call.operation !== null)
  }
}

export async function runClaude({
  binary,
  prompt,
  env = process.env,
  maxTurns,
  model,
  allowedOperations,
  deniedOperations,
  timeoutMs,
  signal,
  stopWhen = () => false,
  onEvent = () => {},
}) {
  const cwd = workDirectory(env)
  await mkdir(cwd, { recursive: true })
  const child = spawn(binary, buildArgs({ maxTurns, model, allowedOperations, deniedOperations }), {
    cwd,
    env: childEnvironment(env),
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  const collector = new StreamCollector()
  const stderr = []
  let stopped = null
  let timedOut = false
  let callbackError = null

  const stop = (reason) => {
    stopped ??= reason
    terminate(child)
  }
  const timer = setTimeout(() => {
    timedOut = true
    stop('timeout')
  }, timeoutMs)
  const onAbort = () => stop('cancelled')
  signal?.addEventListener('abort', onAbort, { once: true })
  if (signal?.aborted) onAbort()

  child.stderr.on('data', (chunk) => {
    if (stderr.length < 64) stderr.push(chunk)
  })
  const lines = createInterface({ input: child.stdout })
  lines.on('line', (line) => {
    if (!line.trim()) return
    let event
    try {
      event = JSON.parse(line)
    } catch {
      return
    }
    try {
      collector.accept(event)
      onEvent(event, collector)
      if (collector.designAvailable === false) stop('design-unavailable')
      else if (stopWhen(collector)) stop('complete')
    } catch (error) {
      callbackError ??= error
      stop('callback-error')
    }
  })

  child.stdin.on('error', () => {})
  child.stdin.end(prompt)

  const exit = await new Promise((resolve, reject) => {
    child.on('error', reject)
    child.on('close', (code, closeSignal) => resolve({ code, signal: closeSignal }))
  }).finally(() => {
    clearTimeout(timer)
    signal?.removeEventListener('abort', onAbort)
  })
  if (callbackError) throw callbackError

  return {
    collector,
    stopped,
    timedOut,
    exitCode: exit.code,
    stderr: redact(Buffer.concat(stderr).toString('utf8'), 1500),
  }
}

export function setupSteps(binary) {
  const quoted = JSON.stringify(binary)
  return [
    `In a terminal on this Mac, run ${quoted} auth login and sign in with the claude.ai account that has Claude Design.`,
    `Start ${quoted} interactively and run /design-consent once (and /design-login if Claude Design later returns 401/403), then exit.`,
  ]
}

export function explainUnavailable(run, binary, auth) {
  if (run.collector.apiError === 'authentication_failed' || auth?.loggedIn === false) {
    return `Claude Code is not signed in. ${setupSteps(binary).join(' ')}`
  }
  if (run.collector.designAvailable === false) {
    return `Claude Code is signed in but the Claude Design MCP server (${DESIGN_MCP_URL}) is unavailable (status: ${run.collector.init.serverStatus}). Start ${JSON.stringify(binary)} interactively, run /design-consent (and /design-login if needed), then retry.`
  }
  if (run.timedOut) return 'The Claude Code run timed out.'
  if (run.stopped === 'cancelled') return 'The request was cancelled.'
  const detail = run.collector.result?.text || run.collector.apiError || run.stderr || `exit ${run.exitCode}`
  return `Claude Code did not complete the request: ${redact(detail, 600)}`
}
