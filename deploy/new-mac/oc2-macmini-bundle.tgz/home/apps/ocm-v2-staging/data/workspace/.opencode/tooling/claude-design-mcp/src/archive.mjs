import { lstat, readdir } from 'node:fs/promises'
import { join, relative } from 'node:path'
import { runCommand } from './process.mjs'
import { ToolError, redact } from './tool-error.mjs'

export const ARCHIVE_LIMITS = Object.freeze({
  maxEntries: 5000,
  maxExtractedBytes: 512 * 1024 * 1024,
})

const TAR_BINARY = '/usr/bin/tar'
const IGNORED_ENTRIES = ['__MACOSX', '.DS_Store']
const ENTRY_LINE =
  /^([-dlhbcps])[-rwxsStTl]{9}[@+.]?\s+\d+\s+\S+\s+\S+\s+(\d+)\s+[A-Za-z]{3}\s+\d{1,2}\s+(?:\d{1,2}:\d{2}|\d{4})\s(.+)$/
const LOCALE_ENV = { LC_ALL: 'en_US.UTF-8', LANG: 'en_US.UTF-8', PATH: '/usr/bin:/bin' }

export function parseListing(text) {
  return text
    .split('\n')
    .filter((line) => line.trim().length > 0)
    .map((line) => {
      const match = ENTRY_LINE.exec(line)
      if (!match) throw new ToolError(`Unrecognised archive listing line: ${redact(line, 200)}`)
      const [, type, size, name] = match
      return { type, size: Number(size), name }
    })
}

function isIgnored(name) {
  return name.split('/').some((segment) => IGNORED_ENTRIES.includes(segment))
}

function hasUnsafePath(name) {
  return name.startsWith('/') || name.split('/').some((segment) => segment === '..')
}

export function validateEntries(entries, limits = ARCHIVE_LIMITS) {
  const relevant = entries.filter((entry) => !isIgnored(entry.name))
  if (relevant.length === 0) throw new ToolError('The archive is empty.')
  if (relevant.length > limits.maxEntries) {
    throw new ToolError(`The archive has ${relevant.length} entries; the limit is ${limits.maxEntries}.`)
  }
  let totalBytes = 0
  for (const entry of relevant) {
    if (entry.type !== '-' && entry.type !== 'd') {
      throw new ToolError(`The archive contains a link or special file (${entry.name}); refusing to extract it.`)
    }
    if (hasUnsafePath(entry.name)) throw new ToolError(`The archive contains an unsafe path: ${entry.name}`)
    totalBytes += entry.size
  }
  if (totalBytes > limits.maxExtractedBytes) {
    throw new ToolError(`The archive expands to ${totalBytes} bytes; the limit is ${limits.maxExtractedBytes}.`)
  }
  return { entries: relevant, totalBytes }
}

async function tar(args, { signal }) {
  const result = await runCommand(TAR_BINARY, args, { env: LOCALE_ENV, signal, timeoutMs: 120_000 })
  if (result.code !== 0) {
    throw new ToolError(`Archive command failed: ${redact(result.stderr || `exit ${result.code}`, 500)}`)
  }
  return result.stdout
}

export async function listArchive(archivePath, { signal } = {}) {
  return parseListing(await tar(['-tvf', archivePath], { signal }))
}

export async function walkFiles(root) {
  const files = []
  const visit = async (directory) => {
    const entries = await readdir(directory, { withFileTypes: true })
    for (const entry of entries) {
      const path = join(directory, entry.name)
      const info = await lstat(path)
      if (info.isSymbolicLink())
        throw new ToolError(`Unexpected symbolic link after extraction: ${relative(root, path)}`)
      if (info.isDirectory()) await visit(path)
      else if (info.isFile()) files.push({ path: relative(root, path), size: info.size })
      else throw new ToolError(`Unexpected special file after extraction: ${relative(root, path)}`)
    }
  }
  await visit(root)
  return files.sort((left, right) => left.path.localeCompare(right.path))
}

export async function extractArchive(archivePath, destination, { signal, limits = ARCHIVE_LIMITS } = {}) {
  validateEntries(await listArchive(archivePath, { signal }), limits)
  const excludes = IGNORED_ENTRIES.flatMap((name) => ['--exclude', name])
  await tar(['-xf', archivePath, '-C', destination, '--no-same-owner', '--no-same-permissions', ...excludes], {
    signal,
  })
  const files = await walkFiles(destination)
  const totalBytes = files.reduce((sum, file) => sum + file.size, 0)
  if (totalBytes > limits.maxExtractedBytes) throw new ToolError('Extracted content exceeds the size limit.')
  return files
}
