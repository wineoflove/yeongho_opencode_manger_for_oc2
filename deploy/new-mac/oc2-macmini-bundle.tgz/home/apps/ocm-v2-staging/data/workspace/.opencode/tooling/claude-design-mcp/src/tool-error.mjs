export class ToolError extends Error {
  constructor(message, details) {
    super(message)
    this.name = 'ToolError'
    this.details = details
  }
}

const SECRET_PATTERNS = [
  [/sk-ant-[A-Za-z0-9_-]{8,}/g, 'sk-ant-<redacted>'],
  [/Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, 'Bearer <redacted>'],
  [/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '<email>'],
]

export function redact(text, maxLength = 2000) {
  const value = String(text ?? '')
  const scrubbed = SECRET_PATTERNS.reduce(
    (current, [pattern, replacement]) => current.replace(pattern, replacement),
    value,
  )
  return scrubbed.length > maxLength ? `${scrubbed.slice(0, maxLength)}…` : scrubbed
}
