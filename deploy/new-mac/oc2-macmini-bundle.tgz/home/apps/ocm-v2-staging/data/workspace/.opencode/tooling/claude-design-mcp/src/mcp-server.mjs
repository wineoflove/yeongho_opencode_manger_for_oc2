import { createInterface } from 'node:readline'
import { ToolError } from './tool-error.mjs'

export const SUPPORTED_PROTOCOL_VERSIONS = Object.freeze(['2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'])
const HEARTBEAT_MS = 10_000

export function errorResult(message, details) {
  const text = details === undefined ? message : `${message}\n${JSON.stringify(details, null, 2)}`
  return { content: [{ type: 'text', text }], isError: true }
}

export function createMcpServer({
  name,
  version,
  instructions,
  tools,
  input = process.stdin,
  output = process.stdout,
}) {
  const toolMap = new Map(tools.map((tool) => [tool.name, tool]))
  const inFlight = new Map()
  const send = (message) => output.write(`${JSON.stringify(message)}\n`)
  const reply = (id, result) => send({ jsonrpc: '2.0', id, result })
  const fail = (id, code, message) => send({ jsonrpc: '2.0', id, error: { code, message } })

  const progressReporter = (token) => {
    let step = 0
    return (message) => {
      if (token === undefined || token === null) return
      step += 1
      send({
        jsonrpc: '2.0',
        method: 'notifications/progress',
        params: { progressToken: token, progress: step, message },
      })
    }
  }

  const callTool = async (id, params) => {
    const tool = toolMap.get(params?.name)
    if (!tool) return fail(id, -32602, `Unknown tool: ${params?.name}`)
    const controller = new AbortController()
    inFlight.set(id, controller)
    const progress = progressReporter(params?._meta?.progressToken)
    const startedAt = Date.now()
    const heartbeat = setInterval(
      () => progress(`Running for ${Math.round((Date.now() - startedAt) / 1000)}s`),
      HEARTBEAT_MS,
    )
    heartbeat.unref()
    controller.signal.addEventListener('abort', () => clearInterval(heartbeat), { once: true })
    try {
      const result = await tool.handler(params.arguments ?? {}, { signal: controller.signal, progress })
      if (!controller.signal.aborted) reply(id, result)
    } catch (error) {
      if (controller.signal.aborted) return
      if (error instanceof ToolError) reply(id, errorResult(error.message, error.details))
      else reply(id, errorResult(`Internal error: ${error instanceof Error ? error.message : String(error)}`))
    } finally {
      clearInterval(heartbeat)
      inFlight.delete(id)
    }
  }

  const handlers = {
    initialize: (params) => ({
      protocolVersion: SUPPORTED_PROTOCOL_VERSIONS.includes(params?.protocolVersion)
        ? params.protocolVersion
        : SUPPORTED_PROTOCOL_VERSIONS[1],
      capabilities: { tools: { listChanged: false } },
      serverInfo: { name, version },
      instructions,
    }),
    ping: () => ({}),
    'tools/list': () => ({
      tools: tools.map(({ name: toolName, title, description, inputSchema, annotations }) => ({
        name: toolName,
        title,
        description,
        inputSchema,
        annotations,
      })),
    }),
  }

  const handleMessage = (message) => {
    if (!message || message.jsonrpc !== '2.0' || typeof message.method !== 'string') {
      if (message && message.id !== undefined && message.method === undefined) return
      return fail(message?.id ?? null, -32600, 'Invalid request')
    }
    const isRequest = message.id !== undefined && message.id !== null
    if (message.method === 'notifications/cancelled') {
      inFlight.get(message.params?.requestId)?.abort()
      return
    }
    if (!isRequest) return
    if (message.method === 'tools/call') return void callTool(message.id, message.params)
    const handler = handlers[message.method]
    if (!handler) return fail(message.id, -32601, `Method not found: ${message.method}`)
    reply(message.id, handler(message.params))
  }

  const lines = createInterface({ input })
  lines.on('line', (line) => {
    if (!line.trim()) return
    let parsed
    try {
      parsed = JSON.parse(line)
    } catch {
      return fail(null, -32700, 'Parse error')
    }
    for (const message of Array.isArray(parsed) ? parsed : [parsed]) handleMessage(message)
  })

  const closed = new Promise((resolve) => lines.on('close', resolve))
  return {
    closed: closed.then(() => {
      for (const controller of inFlight.values()) controller.abort()
    }),
  }
}
